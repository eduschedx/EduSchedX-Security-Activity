<?php
require __DIR__ . '/config.php';
requireOpenActivity();
require_once __DIR__ . '/grader.php';

$challenges = challengeDefinitions();
if (!isset($_SESSION['challenge_order']) || array_diff(array_keys($challenges), (array) $_SESSION['challenge_order']) !== []) {
    $_SESSION['challenge_order'] = array_keys($challenges);
    shuffle($_SESSION['challenge_order']);
}
$currentStep = max(0, min(4, (int) ($_SESSION['challenge_step'] ?? 0)));
$_SESSION['challenge_step'] = $currentStep;
$challengeId = (int) $_SESSION['challenge_order'][$currentStep];
$challenge = $challenges[$challengeId];
$answers = $_SESSION['answer_draft'] ?? array_fill_keys(array_keys($challenges), '');
$challengeResults = $_SESSION['challenge_result'] ?? [];
$challengeErrors = $_SESSION['challenge_error'] ?? [];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Activity | EduSchedX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <script src="app.js" defer></script>
</head>
<body>
    <header class="brand-header"><a href="index.php" class="brand-link"><img src="images/eduschedx-logo.svg" alt="" class="brand-logo"><span class="brand-name">EduSched<span>X</span></span></a></header>
    <main class="activity-shell">
        <section class="activity-card activity-workflow challenge-workflow">
            <?= studentProgress('Activity') ?>
            <div class="screen-panel">
                <div class="panel-heading"><span class="eyebrow">Secure Coding Activity</span><h1>Complete the PHP Checks</h1><p>Type the PHP code itself, then run each challenge.</p></div>
                <?php if (!empty($_SESSION['submit_error'])): ?>
                    <div class="alert alert-warning py-2"><?= escape($_SESSION['submit_error']) ?></div>
                    <?php unset($_SESSION['submit_error']); ?>
                <?php endif; ?>

                <div class="challenge-list">
                        <article class="challenge-card" id="challenge-<?= $challengeId ?>" data-no-copy>
                            <header class="challenge-heading">
                                <span>Challenge <?= $currentStep + 1 ?> of 5</span>
                                <h2><?= escape($challenge['title']) ?></h2>
                            </header>
                            <div class="challenge-code" aria-label="PHP code with one editable answer">
                                <?php if ($challengeId === 3): ?>
                                    <code>if ($requestedRoute === '/admin/dashboard') {</code>
                                    <code>&nbsp;&nbsp;&nbsp;&nbsp;if (______________________________) {</code>
                                    <code>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return false;</code>
                                    <code>&nbsp;&nbsp;&nbsp;&nbsp;}</code>
                                    <code>}</code>
                                <?php elseif ($challengeId === 4): ?>
                                    <code>$allowedRoles = ['SUPERADMIN', 'ADMIN', 'FACULTY'];</code>
                                    <code>&nbsp;</code><code>if (______________________________) {</code><code>&nbsp;&nbsp;&nbsp;&nbsp;return false;</code><code>}</code>
                                <?php elseif ($challengeId === 5): ?>
                                    <code>$user = findUser($studentId);</code>
                                    <code>&nbsp;</code><code>if (!$user) {</code><code>&nbsp;&nbsp;&nbsp;&nbsp;______________________________;</code><code>}</code>
                                <?php else: ?>
                                    <code>if (______________________________) {</code><code>&nbsp;&nbsp;&nbsp;&nbsp;return false;</code><code>}</code>
                                <?php endif; ?>
                            </div>
                            <div class="challenge-body">
                                <div class="code-choices" aria-label="PHP code choices">
                                    <?php foreach ($challenge['choices'] as $choiceIndex => $choice): ?>
                                        <div><strong><?= chr(65 + $choiceIndex) ?>.</strong><code><?= escape($choice) ?></code></div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="challenge-scenario">
                                    <?php foreach ($challenge['scenario'] as $label => $value): ?><span><?= escape($label) ?></span><strong><?= escape($value) ?></strong><?php endforeach; ?>
                                    <span>Expected</span><strong>ACCESS DENIED</strong>
                                </div>
                                <form action="grader.php" method="post" class="challenge-run-form">
                                    <input type="hidden" name="csrf_token" value="<?= escape(csrfToken()) ?>">
                                    <input type="hidden" name="challenge_id" value="<?= $challengeId ?>">
                                    <label class="form-label" for="answer_<?= $challengeId ?>">Your Code</label>
                                    <input class="form-control challenge-answer" id="answer_<?= $challengeId ?>" name="answer_<?= $challengeId ?>" data-answer="<?= $challengeId ?>" value="<?= escape((string) ($answers[$challengeId] ?? '')) ?>" placeholder="Type PHP code" autocomplete="new-password" data-lpignore="true" data-1p-ignore spellcheck="false">
                                    <button class="btn btn-eduschedx" type="submit"><i class="bi bi-play-circle"></i> Run Code</button>
                                </form>
                                <?php if (isset($challengeErrors[$challengeId])): ?>
                                    <div class="alert alert-danger challenge-feedback" role="alert"><?= escape((string) $challengeErrors[$challengeId]) ?></div>
                                <?php elseif (isset($challengeResults[$challengeId])): $preview = $challengeResults[$challengeId]; ?>
                                    <div class="challenge-result <?= $preview['matches'] ? 'is-match' : 'is-mismatch' ?>" role="status">
                                        <span>Actual Result</span><strong><?= $preview['denied'] ? 'ACCESS DENIED' : 'ACCESS GRANTED' ?></strong>
                                        <p><i class="bi <?= $preview['matches'] ? 'bi-check-circle-fill' : 'bi-x-circle-fill' ?>"></i> <?= $preview['matches'] ? 'Matches Expected Result' : 'Does Not Match Expected Result' ?></p>
                                    </div>
                                    <?php if ($currentStep < 4): ?>
                                        <form action="grader.php" method="post" class="challenge-next-form">
                                            <input type="hidden" name="csrf_token" value="<?= escape(csrfToken()) ?>">
                                            <input type="hidden" name="mode" value="next">
                                            <input type="hidden" name="challenge_id" value="<?= $challengeId ?>">
                                            <input type="hidden" name="answer_<?= $challengeId ?>" data-answer-target="<?= $challengeId ?>" value="<?= escape((string) ($answers[$challengeId] ?? '')) ?>">
                                            <button class="btn btn-eduschedx w-100" type="submit">Next Challenge <i class="bi bi-arrow-right"></i></button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </article>
                </div>

                <?php if ($currentStep === 4 && isset($challengeResults[$challengeId])): ?>
                <form id="submit-output" action="submit.php" method="post" class="submit-output-form">
                    <input type="hidden" name="csrf_token" value="<?= escape(csrfToken()) ?>">
                    <?php foreach (array_keys($challenges) as $answerId): ?><input type="hidden" name="answer_<?= $answerId ?>" data-answer-target="<?= $answerId ?>" value="<?= escape((string) ($answers[$answerId] ?? '')) ?>"><?php endforeach; ?>
                    <button class="btn btn-submit-output w-100" type="button" data-bs-toggle="modal" data-bs-target="#submitModal"><i class="bi bi-send me-1"></i> Submit Output</button>
                </form>
                <?php endif; ?>
            </div>
        </section>
    </main>
    <?php if ($currentStep === 4 && isset($challengeResults[$challengeId])): ?><div class="modal fade" id="submitModal" tabindex="-1" aria-labelledby="submitModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered"><div class="modal-content activity-modal">
            <div class="modal-header"><h2 class="modal-title fs-5" id="submitModalTitle">Submit Activity?</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body">Are you sure you want to submit your final answers? You can only submit once.</div>
            <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button type="submit" form="submit-output" class="btn btn-eduschedx" data-confirm-submit>Yes, Submit</button></div>
        </div></div>
    </div><?php endif; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
