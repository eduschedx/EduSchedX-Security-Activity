document.querySelectorAll('form').forEach((form) => {
    form.addEventListener('submit', () => {
        const button = form.querySelector('[data-confirm-submit]')
            || document.querySelector(`[data-confirm-submit][form="${form.id}"]`);
        if (!button) {
            return;
        }
        button.disabled = true;
        button.textContent = 'Submitting...';
    });
});

document.querySelectorAll('[data-answer]').forEach((input) => {
    const target = document.querySelector(`[data-answer-target="${input.dataset.answer}"]`);
    const sync = () => {
        if (target) target.value = input.value;
    };
    input.addEventListener('input', sync);
    sync();
});

document.querySelectorAll('[data-activity-code]').forEach((input) => {
    input.addEventListener('input', () => {
        input.value = input.value.toUpperCase().replace(/[^A-HJ-NP-Z2-9]/g, '').slice(0, 6);
    });
});

document.querySelectorAll('[data-student-id]').forEach((input) => {
    input.addEventListener('input', () => {
        input.value = input.value.toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 10);
    });
});

document.querySelectorAll('[data-auto-dismiss]').forEach((alert) => {
    const delay = Number.parseInt(alert.dataset.autoDismiss, 10);
    if (Number.isFinite(delay) && delay > 0) {
        window.setTimeout(() => alert.remove(), delay);
    }
});

document.querySelectorAll('[data-no-copy]').forEach((area) => {
    ['copy', 'cut', 'paste', 'drop', 'contextmenu'].forEach((eventName) => {
        area.addEventListener(eventName, (event) => event.preventDefault());
    });
});
