<?php
require __DIR__ . '/config.php';
$receipt = $_SESSION['submission_receipt'] ?? null;
if (!is_array($receipt)) {
    header('Location: login.php');
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Submission Received | EduSchedX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <header class="brand-header"><a href="index.php" class="brand-link"><img src="images/eduschedx-logo.svg" alt="" class="brand-logo"><span class="brand-name">EduSched<span>X</span></span></a></header>
    <main class="activity-shell">
        <section class="activity-card compact-card">
            <?= studentProgress('Submit') ?>
            <div class="screen-panel submission-received">
                <div class="submission-icon"><i class="bi bi-check-lg"></i></div>
                <h1>Submission successful</h1>
                <p>Your activity has been submitted.</p>
                <div class="student-summary"><div><strong><?= escape((string) $receipt['full_name']) ?></strong><small><?= escape((string) $receipt['student_id']) ?></small></div><span><?= escape((string) $receipt['assigned_station']) ?></span></div>
                <a class="btn btn-eduschedx btn-label-centered icon-end w-100 mt-3" href="login.php"><span>Return to Login</span><i class="bi bi-arrow-right" aria-hidden="true"></i></a>
            </div>
        </section>
    </main>
</body>
</html>
